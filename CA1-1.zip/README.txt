!!!IMPORTANT NOTICE!!!
This will be repeated on admin user guide as well.

This program is open source, so go nuts on it

For the game to work properly, you need to change all of the filepaths on all of the python files to make sure that the program
functions normally

To "factory reset" the game, you can clear all of the userlist.txt and the gamelog.txt

Thank you for reading this list!!